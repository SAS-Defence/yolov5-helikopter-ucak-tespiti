import argparse
from pathlib import Path
import cv2
import torch
import numpy as np

from sort import Sort

from models.common import DetectMultiBackend
from utils.general import (check_img_size, non_max_suppression, scale_boxes, increment_path)
from utils.augmentations import letterbox
from utils.plots import Annotator, colors

@torch.no_grad()
def run(weights, source, imgsz=832, conf_thres=0.30, iou_thres=0.25, device='0', max_det=300):
    device = torch.device(f'cuda:{device}' if torch.cuda.is_available() and str(device) != 'cpu' else 'cpu')
    model = DetectMultiBackend(weights, device=device)
    stride, names, pt = model.stride, model.names, model.pt
    imgsz = check_img_size(imgsz, s=stride)

    # Her sınıf için ayrı tracker (ID karışmasın diye)
    trackers = {0: Sort(max_age=20, min_hits=2, iou_threshold=0.3),
                1: Sort(max_age=20, min_hits=2, iou_threshold=0.3)}

    source = str(source)
    is_webcam = source.isnumeric()
    cap = cv2.VideoCapture(0 if is_webcam else source)
    assert cap.isOpened(), f"Video açılamadı: {source}"

    save_dir = increment_path(Path('runs/track/exp'), exist_ok=False)
    save_dir.mkdir(parents=True, exist_ok=True)
    out_path = str(save_dir / 'tracked.mp4')

    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        img = letterbox(frame, imgsz, stride=stride, auto=True)[0]
        img = img.transpose((2, 0, 1))[::-1]  # BGR->RGB, HWC->CHW
        img = np.ascontiguousarray(img)

        im = torch.from_numpy(img).to(device)
        im = im.float() / 255.0
        if im.ndimension() == 3:
            im = im[None]

        pred = model(im)
        pred = non_max_suppression(pred, conf_thres, iou_thres, max_det=max_det)

        annotator = Annotator(frame, line_width=3)

        for det in pred:
            if len(det):
                det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], frame.shape).round()

                # Sınıf bazlı takip
                for cls_id in [0, 1]:
                    cls_mask = (det[:, 5].int() == cls_id)
                    det_cls = det[cls_mask]

                    if len(det_cls) == 0:
                        trackers[cls_id].update(np.empty((0, 5)))
                        continue

                    dets = []
                    for *xyxy, conf, cls in det_cls:
                        x1, y1, x2, y2 = [float(x) for x in xyxy]
                        dets.append([x1, y1, x2, y2, float(conf)])
                    dets = np.array(dets, dtype=np.float32)

                    tracks = trackers[cls_id].update(dets)

                    # Çiz
                    for x1, y1, x2, y2, tid in tracks:
                        label = f"{names[cls_id]} ID:{int(tid)}"
                        annotator.box_label([x1, y1, x2, y2], label, color=colors(cls_id, True))

        out = annotator.result()
        writer.write(out)
        cv2.imshow("YOLOv5 + SORT Tracking", out)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"Kaydedildi: {out_path}")

def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, required=True)
    parser.add_argument('--source', type=str, required=True)
    parser.add_argument('--img', type=int, default=832)
    parser.add_argument('--conf-thres', type=float, default=0.30)
    parser.add_argument('--iou-thres', type=float, default=0.25)
    parser.add_argument('--device', type=str, default='0')
    parser.add_argument('--max-det', type=int, default=300)
    return parser.parse_args()

if __name__ == "__main__":
    opt = parse_opt()
    run(opt.weights, opt.source, opt.img, opt.conf_thres, opt.iou_thres, opt.device, opt.max_det)
